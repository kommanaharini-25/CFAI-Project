"""
Safety Module: Real-time hazard detection, alerts, and emergency routing
"""

from typing import Dict, List, Set, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import heapq

class AlertSeverity(Enum):
    """Severity levels of alerts"""
    INFO = 1
    WARNING = 2
    CRITICAL = 3
    EMERGENCY = 4

class HazardStatus(Enum):
    """Status of hazards"""
    DETECTED = "detected"
    CONTAINED = "contained"
    RESOLVED = "resolved"
    MONITORING = "monitoring"

@dataclass
class Hazard:
    """Represents a hazard in the environment"""
    id: str
    location_id: str
    hazard_type: str  # "fire", "flood", "obstacle", "crowd"
    severity: AlertSeverity
    timestamp: datetime = field(default_factory=datetime.now)
    affected_area_radius: float = 50.0  # meters
    status: HazardStatus = HazardStatus.DETECTED
    description: str = ""
    
    def is_active(self) -> bool:
        """Check if hazard is still active"""
        return self.status in [HazardStatus.DETECTED, HazardStatus.MONITORING]
    
    def __lt__(self, other):
        """For priority queue: higher severity first"""
        return self.severity.value > other.severity.value

@dataclass
class Alert:
    """User alert about hazards"""
    id: str
    user_id: str
    hazard_id: str
    message: str
    severity: AlertSeverity
    timestamp: datetime = field(default_factory=datetime.now)
    is_read: bool = False
    recommended_action: str = ""
    
    def __lt__(self, other):
        """For priority queue"""
        if self.severity != other.severity:
            return self.severity.value > other.severity.value
        return self.timestamp < other.timestamp

class HazardDetector:
    """Detect and track hazards in real-time"""
    
    def __init__(self):
        self.active_hazards: Dict[str, Hazard] = {}
        self.hazard_history: List[Hazard] = []
        self.detection_callbacks: List = []
    
    def register_callback(self, callback):
        """Register callback for hazard detection"""
        self.detection_callbacks.append(callback)
    
    def detect_hazard(self, location_id: str, hazard_type: str, 
                     severity: AlertSeverity, description: str = "") -> Hazard:
        """Detect a new hazard"""
        hazard_id = f"hazard_{location_id}_{len(self.active_hazards)}"
        hazard = Hazard(
            id=hazard_id,
            location_id=location_id,
            hazard_type=hazard_type,
            severity=severity,
            description=description
        )
        
        self.active_hazards[hazard_id] = hazard
        self.hazard_history.append(hazard)
        
        # Trigger callbacks
        for callback in self.detection_callbacks:
            callback(hazard)
        
        return hazard
    
    def update_hazard_status(self, hazard_id: str, status: HazardStatus):
        """Update hazard status"""
        if hazard_id in self.active_hazards:
            self.active_hazards[hazard_id].status = status
            if status == HazardStatus.RESOLVED:
                del self.active_hazards[hazard_id]
    
    def get_hazards_near_location(self, location_id: str, radius: float) -> List[Hazard]:
        """Get active hazards near a location (requires distance calculation)"""
        # In real implementation, would check actual distances
        return [h for h in self.active_hazards.values() 
                if h.location_id == location_id or h.affected_area_radius >= radius]
    
    def get_active_hazards(self) -> List[Hazard]:
        """Get all active hazards"""
        return list(self.active_hazards.values())


class AlertSystem:
    """Manage and deliver alerts to users"""
    
    def __init__(self):
        self.alerts: Dict[str, List[Alert]] = {}  # user_id -> list of alerts
        self.alert_queue: List[Alert] = []
        self.alert_history: List[Alert] = []
    
    def create_alert(self, user_id: str, hazard: Hazard) -> Alert:
        """Create alert for user about hazard"""
        severity_actions = {
            AlertSeverity.INFO: "Continue with caution",
            AlertSeverity.WARNING: "Consider alternate route",
            AlertSeverity.CRITICAL: "Take alternate route immediately",
            AlertSeverity.EMERGENCY: "Evacuate to nearest safe zone"
        }
        
        alert = Alert(
            id=f"alert_{user_id}_{hazard.id}",
            user_id=user_id,
            hazard_id=hazard.id,
            message=f"{hazard.hazard_type.upper()} detected at {hazard.location_id}",
            severity=hazard.severity,
            recommended_action=severity_actions[hazard.severity]
        )
        
        if user_id not in self.alerts:
            self.alerts[user_id] = []
        
        self.alerts[user_id].append(alert)
        heapq.heappush(self.alert_queue, alert)
        self.alert_history.append(alert)
        
        return alert
    
    def get_user_alerts(self, user_id: str, unread_only: bool = False) -> List[Alert]:
        """Get alerts for a user"""
        if user_id not in self.alerts:
            return []
        
        alerts = self.alerts[user_id]
        if unread_only:
            return [a for a in alerts if not a.is_read]
        return alerts
    
    def mark_alert_read(self, alert_id: str):
        """Mark alert as read"""
        for alerts_list in self.alerts.values():
            for alert in alerts_list:
                if alert.id == alert_id:
                    alert.is_read = True
                    return
    
    def get_critical_alerts(self) -> List[Alert]:
        """Get all unread critical/emergency alerts"""
        critical = []
        for alerts_list in self.alerts.values():
            for alert in alerts_list:
                if not alert.is_read and alert.severity in [AlertSeverity.CRITICAL, AlertSeverity.EMERGENCY]:
                    critical.append(alert)
        return sorted(critical)


class EmergencyRouter:
    """Route users to safety during emergencies"""
    
    def __init__(self, graph, safe_zones: List[str]):
        self.graph = graph
        self.safe_zones = safe_zones
    
    def find_nearest_safe_zone(self, current_location_id: str) -> Tuple[Optional[str], float]:
        """Find the nearest safe zone using shortest weighted path."""
        distances = {current_location_id: 0.0}
        visited = set()
        priority_queue = [(0.0, current_location_id)]
        
        while priority_queue:
            current_distance, loc_id = heapq.heappop(priority_queue)
            if loc_id in visited:
                continue
            visited.add(loc_id)
            
            if loc_id in self.safe_zones:
                return loc_id, current_distance
            
            for neighbor_id in self.graph.adjacency_list[loc_id]:
                edge_cost = sum(e.cost() for e in self.graph.edges[loc_id]
                                if e.to_loc.id == neighbor_id)
                new_distance = current_distance + edge_cost
                if new_distance < distances.get(neighbor_id, float('inf')):
                    distances[neighbor_id] = new_distance
                    heapq.heappush(priority_queue, (new_distance, neighbor_id))
        
        return None, float('inf')
    
    def plan_emergency_evacuation(self, current_location_id: str) -> List[str]:
        """Plan emergency evacuation route to nearest safe zone"""
        safe_zone_id, _ = self.find_nearest_safe_zone(current_location_id)
        
        if safe_zone_id is None:
            return []
        
        # Use Dijkstra to find path to safe zone
        distances = {nid: float('inf') for nid in self.graph.nodes}
        distances[current_location_id] = 0
        parent = {}
        visited = set()
        
        import heapq
        pq = [(0, current_location_id)]
        
        while pq:
            curr_dist, curr_id = heapq.heappop(pq)
            
            if curr_id in visited:
                continue
            visited.add(curr_id)
            
            if curr_id == safe_zone_id:
                # Reconstruct path
                path = []
                node = safe_zone_id
                while node in parent:
                    path.append(node)
                    node = parent[node]
                path.append(current_location_id)
                return path[::-1]
            
            for edge in self.graph.edges[curr_id]:
                neighbor_id = edge.to_loc.id
                new_dist = curr_dist + edge.cost()
                
                if new_dist < distances[neighbor_id]:
                    distances[neighbor_id] = new_dist
                    parent[neighbor_id] = curr_id
                    heapq.heappush(pq, (new_dist, neighbor_id))
        
        return []
    
    def get_evacuation_status(self, num_people: int, capacity: Dict[str, int]) -> Dict:
        """Get evacuation status and capacity"""
        total_capacity = sum(capacity.values())
        utilization = (num_people / total_capacity * 100) if total_capacity > 0 else 0
        
        return {
            "total_people": num_people,
            "total_capacity": total_capacity,
            "utilization_percent": utilization,
            "status": "CRITICAL" if utilization > 90 else "WARNING" if utilization > 70 else "OK"
        }


class SafetyMetrics:
    """Track safety metrics for the platform"""
    
    def __init__(self):
        self.total_incidents = 0
        self.incidents_resolved = 0
        self.average_response_time = 0.0  # seconds
        self.user_safety_ratings: List[float] = []
    
    def record_incident(self, hazard: Hazard):
        """Record a safety incident"""
        self.total_incidents += 1
    
    def record_resolution(self, response_time: float):
        """Record incident resolution"""
        self.incidents_resolved += 1
        # Update average response time
        self.average_response_time = (
            (self.average_response_time * (self.incidents_resolved - 1) + response_time) 
            / self.incidents_resolved
        )
    
    def add_user_rating(self, rating: float):
        """Add user safety rating (0-100)"""
        self.user_safety_ratings.append(rating)
    
    def get_safety_score(self) -> float:
        """Calculate overall platform safety score"""
        if not self.user_safety_ratings:
            return 100.0
        
        avg_rating = sum(self.user_safety_ratings) / len(self.user_safety_ratings)
        incident_penalty = (self.total_incidents - self.incidents_resolved) * 5
        
        return max(0, min(100, avg_rating - incident_penalty))
    
    def get_statistics(self) -> Dict:
        """Get safety statistics"""
        return {
            "total_incidents": self.total_incidents,
            "resolved": self.incidents_resolved,
            "unresolved": self.total_incidents - self.incidents_resolved,
            "avg_response_time_sec": self.average_response_time,
            "avg_user_rating": sum(self.user_safety_ratings) / len(self.user_safety_ratings) if self.user_safety_ratings else 100.0,
            "overall_safety_score": self.get_safety_score()
        }
