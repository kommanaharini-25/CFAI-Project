"""
Heuristic Design and Evaluation for Safe Path
Admissibility, consistency, heuristic quality metrics
"""

from typing import Callable, Dict, Tuple, Optional
from models import Location
from knowledge_representation import Graph
import math

class HeuristicEvaluator:
    """Evaluate quality and properties of heuristics"""
    
    @staticmethod
    def is_admissible(heuristic: Callable, actual_costs: Dict[Tuple[str, str], float]) -> bool:
        """
        Check if h(n) <= actual_cost(n, goal) for all n
        Admissible heuristics guarantee optimal solution with A*
        """
        for (n, goal), actual_cost in actual_costs.items():
            h_value = heuristic(n, goal)
            if h_value > actual_cost:
                return False
        return True
    
    @staticmethod
    def is_consistent(heuristic: Callable, edges: Dict[str, list], goal: str) -> bool:
        """
        Check if h(n) <= c(n, n') + h(n') for all edges (n, n')
        Consistent heuristics guarantee optimal path in A*
        """
        for current_id, neighbors in edges.items():
            h_curr = heuristic(current_id, goal)
            for edge in neighbors:
                neighbor_id = edge.to_loc.id
                h_next = heuristic(neighbor_id, goal)
                if h_curr > edge.cost() + h_next:
                    return False
        return True
    
    @staticmethod
    def calculate_effective_branching_factor(nodes_expanded: int, path_length: int) -> float:
        """
        Effective branching factor: how much search tree is pruned
        Lower is better (means heuristic is more informative)
        b* such that b*^(path_length) = nodes_expanded
        """
        if nodes_expanded == 0 or path_length == 0:
            return 0
        try:
            return nodes_expanded ** (1 / path_length)
        except:
            return float('inf')
    
    @staticmethod
    def heuristic_quality(h_value: float, actual_cost: float) -> float:
        """
        Quality score: how close heuristic is to actual cost
        Range: [0, 1] where 1 is perfect
        """
        if actual_cost == 0:
            return 1.0 if h_value == 0 else 0.0
        return max(0, min(1, 1 - (actual_cost - h_value) / actual_cost))


class SafePathHeuristics:
    """Collection of heuristics for Safe Path navigation"""
    
    @staticmethod
    def euclidean_distance(graph: Graph) -> Callable[[str, str], float]:
        """
        Euclidean distance heuristic: sqrt((x2-x1)^2 + (y2-y1)^2)
        Admissible for 2D navigation
        """
        def heuristic(node_id: str, goal_id: str) -> float:
            node = graph.nodes[node_id]
            goal = graph.nodes[goal_id]
            return node.distance_to(goal)
        return heuristic
    
    @staticmethod
    def manhattan_distance(graph: Graph) -> Callable[[str, str], float]:
        """
        Manhattan distance heuristic: |x2-x1| + |y2-y1|
        Admissible for grid-based navigation
        """
        def heuristic(node_id: str, goal_id: str) -> float:
            node = graph.nodes[node_id]
            goal = graph.nodes[goal_id]
            return abs(node.x - goal.x) + abs(node.y - goal.y)
        return heuristic
    
    @staticmethod
    def safety_weighted_distance(graph: Graph, safety_weight: float = 0.3) -> Callable[[str, str], float]:
        """
        Combined heuristic: distance + safety penalty
        Good for: balancing speed and safety
        h(n) = distance(n, goal) + safety_weight * (100 - safety_score)
        """
        def heuristic(node_id: str, goal_id: str) -> float:
            node = graph.nodes[node_id]
            goal = graph.nodes[goal_id]
            distance = node.distance_to(goal)
            # Safety component (assumes safety_score stored in location)
            safety_penalty = safety_weight * max(0, 100 - getattr(node, 'safety_score', 100))
            return distance + safety_penalty
        return heuristic
    
    @staticmethod
    def accessibility_weighted_distance(graph: Graph, accessibility_weight: float = 0.2) -> Callable[[str, str], float]:
        """
        Heuristic for users with mobility constraints
        h(n) = distance(n, goal) + accessibility_weight * accessibility_penalty
        """
        def heuristic(node_id: str, goal_id: str) -> float:
            node = graph.nodes[node_id]
            goal = graph.nodes[goal_id]
            distance = node.distance_to(goal)
            # Accessibility penalty
            accessibility_penalty = accessibility_weight * max(0, 100 - getattr(node, 'accessibility_score', 100))
            return distance + accessibility_penalty
        return heuristic
    
    @staticmethod
    def floor_aware_heuristic(graph: Graph) -> Callable[[str, str], float]:
        """
        Heuristic considering multi-floor buildings
        Adds vertical distance penalty for floor changes
        """
        def heuristic(node_id: str, goal_id: str) -> float:
            node = graph.nodes[node_id]
            goal = graph.nodes[goal_id]
            
            # Horizontal distance
            h_distance = math.sqrt((node.x - goal.x)**2 + (node.y - goal.y)**2)
            
            # Vertical distance (floor penalty)
            floor_penalty = abs(node.floor - goal.floor) * 15  # Estimate: 15 units per floor
            
            return h_distance + floor_penalty
        return heuristic
    
    @staticmethod
    def landmark_heuristic(graph: Graph, landmarks: Dict[str, Tuple[float, float]]) -> Callable[[str, str], float]:
        """
        Precomputed distances to landmark locations
        Good for: multiple queries, real-time performance
        """
        # Precompute distances from all nodes to landmarks
        landmark_distances = {}
        for lm_id, (lm_x, lm_y) in landmarks.items():
            for node_id, node in graph.nodes.items():
                dist = math.sqrt((node.x - lm_x)**2 + (node.y - lm_y)**2)
                landmark_distances[(node_id, lm_id)] = dist
        
        def heuristic(node_id: str, goal_id: str) -> float:
            max_h = 0
            for lm_id in landmarks:
                # Triangle inequality: h(n) = max(|dist(n,L) - dist(L,goal)|)
                dist_n_lm = landmark_distances.get((node_id, lm_id), 0)
                dist_goal_lm = landmark_distances.get((goal_id, lm_id), 0)
                h_value = abs(dist_n_lm - dist_goal_lm)
                max_h = max(max_h, h_value)
            return max_h
        
        return heuristic
    
    @staticmethod
    def null_heuristic() -> Callable[[str, str], float]:
        """
        Null heuristic: always returns 0
        Makes A* equivalent to UCS (Dijkstra)
        """
        def heuristic(node_id: str, goal_id: str) -> float:
            return 0.0
        return heuristic


class HeuristicComparison:
    """Compare multiple heuristics for performance"""
    
    def __init__(self):
        self.results: Dict[str, Dict] = {}
    
    def add_comparison(self, heuristic_name: str, nodes_expanded: int, 
                      path_length: int, total_cost: float, time_taken: float):
        """Record heuristic performance"""
        self.results[heuristic_name] = {
            "nodes_expanded": nodes_expanded,
            "path_length": path_length,
            "total_cost": total_cost,
            "time_taken": time_taken,
            "effective_branching": HeuristicEvaluator.calculate_effective_branching_factor(
                nodes_expanded, path_length
            )
        }
    
    def get_best_heuristic(self, metric: str = "nodes_expanded") -> Optional[str]:
        """Get heuristic with best performance on given metric"""
        if not self.results:
            return None
        return min(self.results.keys(), key=lambda k: self.results[k][metric])
    
    def print_summary(self):
        """Print comparison summary"""
        print("\n=== Heuristic Comparison ===")
        print(f"{'Heuristic':<25} {'Expanded':<10} {'Path Len':<10} {'Cost':<10} {'Time':<10} {'Br.Factor':<10}")
        print("-" * 75)
        for name, metrics in self.results.items():
            print(f"{name:<25} {metrics['nodes_expanded']:<10} {metrics['path_length']:<10} "
                  f"{metrics['total_cost']:<10.2f} {metrics['time_taken']:<10.4f} {metrics['effective_branching']:<10.2f}")
