"""
Knowledge Representation: Graph, Tree, and Rule-based structures for Safe Path
"""

from typing import Dict, List, Set, Tuple, Optional
from dataclasses import dataclass, field
from models import Location, Edge, HazardType
from collections import defaultdict
import heapq

class Graph:
    """
    Represents the environment as a directed graph
    Nodes: Locations (waypoints, exits, facilities)
    Edges: Connections with costs and hazards
    """
    
    def __init__(self, name: str = "Campus"):
        self.name = name
        self.nodes: Dict[str, Location] = {}
        self.edges: Dict[str, List[Edge]] = defaultdict(list)
        self.adjacency_list: Dict[str, List[str]] = defaultdict(list)
    
    def add_node(self, location: Location) -> None:
        """Add a location node to graph"""
        self.nodes[location.id] = location
    
    def add_edge(self, edge: Edge) -> None:
        """Add a directed edge"""
        from_id = edge.from_loc.id
        to_id = edge.to_loc.id
        
        if from_id not in self.nodes or to_id not in self.nodes:
            raise ValueError("Both locations must exist in graph")
        
        self.edges[from_id].append(edge)
        self.adjacency_list[from_id].append(to_id)
    
    def get_neighbors(self, location_id: str) -> List[Location]:
        """Get all neighboring locations"""
        return [self.nodes[nid] for nid in self.adjacency_list[location_id]]
    
    def get_edges_from(self, location_id: str) -> List[Edge]:
        """Get all edges from a location"""
        return self.edges[location_id]
    
    def is_connected(self) -> bool:
        """Check if graph is connected (can reach from any node to any other)"""
        if not self.nodes:
            return True
        
        visited = set()
        stack = [next(iter(self.nodes.keys()))]
        
        while stack:
            node = stack.pop()
            if node not in visited:
                visited.add(node)
                stack.extend(self.adjacency_list[node])
        
        return len(visited) == len(self.nodes)
    
    def shortest_path_dijkstra(self, start_id: str, end_id: str) -> Optional[List[Location]]:
        """Dijkstra's algorithm for shortest path"""
        if start_id not in self.nodes or end_id not in self.nodes:
            return None
        
        distances = {nid: float('inf') for nid in self.nodes}
        distances[start_id] = 0
        parent = {}
        visited = set()
        
        pq = [(0.0, start_id)]
        
        while pq:
            curr_dist, curr_id = heapq.heappop(pq)
            if curr_id in visited:
                continue
            visited.add(curr_id)
            
            if curr_id == end_id:
                # Reconstruct path
                path = []
                node = end_id
                while node in parent:
                    path.append(self.nodes[node])
                    node = parent[node]
                path.append(self.nodes[start_id])
                return path[::-1]
            
            for edge in self.edges[curr_id]:
                neighbor_id = edge.to_loc.id
                new_dist = distances[curr_id] + edge.cost()
                
                if new_dist < distances[neighbor_id]:
                    distances[neighbor_id] = new_dist
                    parent[neighbor_id] = curr_id
                    heapq.heappush(pq, (new_dist, neighbor_id))
        
        return None


class DecisionTree:
    """
    Rule-based decision tree for route selection
    Used for choosing between multiple paths based on criteria
    """
    
    @dataclass
    class Node:
        feature: Optional[str] = None  # "time", "safety", "distance", etc.
        threshold: Optional[float] = None
        left: Optional['DecisionTree.Node'] = None
        right: Optional['DecisionTree.Node'] = None
        decision: Optional[str] = None  # Leaf node value
        
        def is_leaf(self) -> bool:
            return self.decision is not None
    
    def __init__(self):
        self.root: Optional['DecisionTree.Node'] = None
    
    def build_simple_tree(self):
        """Build a simple decision tree for route selection"""
        # Root: Check safety score
        self.root = self.Node(feature="safety_score", threshold=70)
        
        # Left subtree: Low safety - prioritize exits
        self.root.left = self.Node(feature="distance_to_exit", threshold=50)
        self.root.left.left = self.Node(decision="FASTEST_EXIT")
        self.root.left.right = self.Node(decision="SAFEST_EXIT")
        
        # Right subtree: High safety - balance time and distance
        self.root.right = self.Node(feature="time_constraint", threshold=300)
        self.root.right.left = self.Node(decision="FASTEST_ROUTE")
        self.root.right.right = self.Node(decision="SHORTEST_ROUTE")
    
    def predict(self, features: Dict[str, float]) -> str:
        """Traverse tree and make prediction"""
        node = self.root
        while not node.is_leaf():
            feature_val = features.get(node.feature, 0)
            if feature_val < node.threshold:
                node = node.left
            else:
                node = node.right
        return node.decision


@dataclass
class Rule:
    """Constraint rule for navigation"""
    name: str
    condition: str  # Description for explainability
    priority: int  # 1 (highest) to 5 (lowest)
    applies_to: str  # "hazard", "time", "accessibility"
    action: str  # What to do if rule applies
    is_hard: bool = True  # Hard = must satisfy, Soft = prefer
    
    def __lt__(self, other):
        """For sorting by priority"""
        return self.priority < other.priority


class RuleSet:
    """Collection of rules for Safe Path constraints"""
    
    def __init__(self):
        self.rules: List[Rule] = []
    
    def add_rule(self, rule: Rule) -> None:
        self.rules.append(rule)
    
    def get_applicable_rules(self, context: Dict[str, any]) -> List[Rule]:
        """Get rules applicable to current context"""
        applicable = []
        for rule in self.rules:
            if rule.applies_to in context:
                applicable.append(rule)
        return sorted(applicable, key=lambda r: r.priority)
    
    def initialize_default_rules(self) -> None:
        """Initialize standard rules for Safe Path"""
        rules = [
            Rule("AVOID_FIRE", "Active fire hazard in area", 1, "hazard", 
                 "DIVERT_ROUTE", is_hard=True),
            Rule("PRIORITIZE_EXITS", "Emergency evacuation needed", 1, "hazard", 
                 "ROUTE_TO_NEAREST_EXIT", is_hard=True),
            Rule("AVOID_BLOCKED", "Path blocked by obstacles", 2, "hazard", 
                 "USE_ALTERNATE_ROUTE", is_hard=True),
            Rule("REDUCE_CONGESTION", "High congestion area", 3, "hazard", 
                 "SUGGEST_ALTERNATE_ROUTE", is_hard=False),
            Rule("ACCESSIBILITY_PRIORITY", "User has mobility constraints", 2, "accessibility", 
                 "PREFER_ACCESSIBLE_ROUTES", is_hard=True),
            Rule("TIME_CONSTRAINT", "Urgent appointment", 4, "time", 
                 "PRIORITIZE_SPEED", is_hard=False),
        ]
        for rule in rules:
            self.add_rule(rule)
