"""
Unit Tests for Safe Path Campus Navigation App.
Demonstrates CO1: Testing and debugging algorithm units.
"""

import unittest
from models import Location, Edge, State, PEASModel, EnvironmentType
from knowledge_representation import Graph
from search_algorithms import BFS, DFS, UCS, Greedy, AStar, SearchMetrics
from heuristics import SafePathHeuristics, HeuristicEvaluator
from safety_module import EmergencyRouter, HazardDetector, AlertSeverity


class TestLocationAndEdge(unittest.TestCase):
    """Test location and edge creation and calculations."""
    
    def setUp(self):
        self.loc1 = Location("loc1", "Location 1", 0, 0, floor=0)
        self.loc2 = Location("loc2", "Location 2", 3, 4, floor=0)
    
    def test_distance_calculation(self):
        """Test Euclidean distance between locations."""
        dist = self.loc1.distance_to(self.loc2)
        self.assertAlmostEqual(dist, 5.0, places=1)  # 3-4-5 triangle
    
    def test_edge_cost_normal(self):
        """Test edge cost calculation."""
        edge = Edge(self.loc1, self.loc2, weight=10.0, accessibility=1.0)
        self.assertEqual(edge.cost(), 10.0)
    
    def test_edge_cost_with_accessibility(self):
        """Test edge cost adjusted by accessibility."""
        edge = Edge(self.loc1, self.loc2, weight=10.0, accessibility=0.5)
        self.assertEqual(edge.cost(), 20.0)  # cost / accessibility
    
    def test_edge_blocked(self):
        """Test blocked edge returns infinite cost."""
        edge = Edge(self.loc1, self.loc2, weight=10.0, is_blocked=True)
        self.assertEqual(edge.cost(), float('inf'))
    
    def test_location_equality(self):
        """Test location equality based on ID."""
        loc_copy = Location("loc1", "Location 1", 0, 0)
        self.assertEqual(self.loc1, loc_copy)


class TestGraph(unittest.TestCase):
    """Test graph construction and operations."""
    
    def setUp(self):
        self.graph = Graph("Test Graph")
        self.loc_a = Location("a", "Location A", 0, 0)
        self.loc_b = Location("b", "Location B", 5, 0)
        self.loc_c = Location("c", "Location C", 5, 5)
        
        self.graph.add_node(self.loc_a)
        self.graph.add_node(self.loc_b)
        self.graph.add_node(self.loc_c)
    
    def test_graph_nodes_added(self):
        """Test nodes are added to graph."""
        self.assertEqual(len(self.graph.nodes), 3)
        self.assertIn("a", self.graph.nodes)
    
    def test_add_edge(self):
        """Test edge addition."""
        edge = Edge(self.loc_a, self.loc_b, weight=5.0)
        self.graph.add_edge(edge)
        self.assertEqual(len(self.graph.edges["a"]), 1)
        self.assertIn("b", self.graph.adjacency_list["a"])
    
    def test_neighbors(self):
        """Test getting neighbors."""
        edge = Edge(self.loc_a, self.loc_b, weight=5.0)
        self.graph.add_edge(edge)
        neighbors = self.graph.get_neighbors("a")
        self.assertEqual(len(neighbors), 1)
        self.assertEqual(neighbors[0].id, "b")
    
    def test_graph_connectivity(self):
        """Test graph connectivity check."""
        # Initially disconnected
        self.assertFalse(self.graph.is_connected())
        
        # Connect all nodes
        self.graph.add_edge(Edge(self.loc_a, self.loc_b, weight=5.0))
        self.graph.add_edge(Edge(self.loc_b, self.loc_c, weight=5.0))
        self.assertTrue(self.graph.is_connected())


class TestSearchAlgorithms(unittest.TestCase):
    """Test search algorithms on a simple graph."""
    
    def setUp(self):
        """Create a simple linear graph: A--5--B--3--C."""
        self.graph = Graph("Simple Test")
        self.loc_a = Location("a", "A", 0, 0)
        self.loc_b = Location("b", "B", 5, 0)
        self.loc_c = Location("c", "C", 8, 0)
        
        self.graph.add_node(self.loc_a)
        self.graph.add_node(self.loc_b)
        self.graph.add_node(self.loc_c)
        
        self.graph.add_edge(Edge(self.loc_a, self.loc_b, weight=5.0))
        self.graph.add_edge(Edge(self.loc_b, self.loc_c, weight=3.0))
    
    def test_bfs_finds_path(self):
        """Test BFS finds a path."""
        bfs = BFS(self.graph)
        path, metrics = bfs.search("a", "c")
        self.assertIsNotNone(path)
        self.assertEqual(len(path), 3)
        self.assertEqual([loc.id for loc in path], ["a", "b", "c"])
    
    def test_dfs_finds_path(self):
        """Test DFS finds a path."""
        dfs = DFS(self.graph)
        path, metrics = dfs.search("a", "c")
        self.assertIsNotNone(path)
        self.assertEqual([loc.id for loc in path], ["a", "b", "c"])
    
    def test_ucs_optimal_cost(self):
        """Test UCS finds optimal cost path."""
        ucs = UCS(self.graph)
        path, metrics = ucs.search("a", "c")
        self.assertIsNotNone(path)
        self.assertAlmostEqual(metrics.total_cost, 8.0)  # 5 + 3
    
    def test_no_path_found(self):
        """Test algorithm returns None for unreachable goal."""
        # Add disconnected node
        loc_d = Location("d", "D", 100, 100)
        self.graph.add_node(loc_d)
        
        bfs = BFS(self.graph)
        path, metrics = bfs.search("a", "d")
        self.assertIsNone(path)
    
    def test_start_equals_goal(self):
        """Test path when start = goal (edge case)."""
        bfs = BFS(self.graph)
        # Note: Some implementations may return empty or single-node path
        path, metrics = bfs.search("a", "a")
        if path is not None:
            self.assertEqual(path[0].id, "a")


class TestHeuristics(unittest.TestCase):
    """Test heuristic functions and properties."""
    
    def setUp(self):
        self.graph = Graph("Test")
        self.loc_a = Location("a", "A", 0, 0)
        self.loc_b = Location("b", "B", 3, 4)
        self.graph.add_node(self.loc_a)
        self.graph.add_node(self.loc_b)
    
    def test_euclidean_heuristic(self):
        """Test Euclidean distance heuristic."""
        h = SafePathHeuristics.euclidean_distance(self.graph)
        h_val = h("a", "b")
        self.assertAlmostEqual(h_val, 5.0, places=1)  # 3-4-5 triangle
    
    def test_manhattan_heuristic(self):
        """Test Manhattan distance heuristic."""
        h = SafePathHeuristics.manhattan_distance(self.graph)
        h_val = h("a", "b")
        self.assertEqual(h_val, 7.0)  # |3| + |4|
    
    def test_null_heuristic(self):
        """Test null heuristic returns 0."""
        h = SafePathHeuristics.null_heuristic()
        h_val = h("a", "b")
        self.assertEqual(h_val, 0.0)


class TestPEASModel(unittest.TestCase):
    """Test PEAS model for route evaluation."""
    
    def setUp(self):
        self.peas = PEASModel(environment_type=EnvironmentType.CAMPUS)
        self.loc_start = Location("start", "Start", 0, 0)
        self.loc_goal = Location("goal", "Goal", 10, 10)
    
    def test_peas_initialization(self):
        """Test PEAS model initializes correctly."""
        self.assertEqual(self.peas.environment_type, EnvironmentType.CAMPUS)
        self.assertFalse(self.peas.is_deterministic)
        self.assertTrue(self.peas.is_discrete)
    
    def test_performance_evaluation(self):
        """Test performance scoring."""
        state = State(
            current_location=self.loc_goal,
            goal_location=self.loc_goal,
            path_taken=[self.loc_start, self.loc_goal],
            time_elapsed=10.0,
            safety_score=90.0
        )
        score = self.peas.evaluate_performance(state)
        self.assertGreater(score, 0)
        self.assertLessEqual(score, 100)


class TestHazardDetection(unittest.TestCase):
    """Test safety module hazard detection."""
    
    def setUp(self):
        self.detector = HazardDetector()
    
    def test_hazard_detection(self):
        """Test hazard detection and storage."""
        hazard = self.detector.detect_hazard(
            "loc_1", "fire", AlertSeverity.CRITICAL, "Active fire in building"
        )
        self.assertEqual(hazard.location_id, "loc_1")
        self.assertEqual(hazard.hazard_type, "fire")
        self.assertTrue(hazard.is_active())
    
    def test_multiple_hazards(self):
        """Test tracking multiple hazards."""
        self.detector.detect_hazard("loc_1", "fire", AlertSeverity.CRITICAL)
        self.detector.detect_hazard("loc_2", "flood", AlertSeverity.WARNING)
        self.assertEqual(len(self.detector.get_active_hazards()), 2)


class TestIntegration(unittest.TestCase):
    """Integration tests combining multiple components."""
    
    def test_complete_routing_workflow(self):
        """Test complete routing from app functions."""
        from safe_path_app import build_campus_graph, find_shortest_route
        
        graph, name_map = build_campus_graph()
        start = name_map["LIBRARY"]
        goal = name_map["LAB"]
        
        path, cost = find_shortest_route(graph, start, goal)
        self.assertIsNotNone(path)
        self.assertGreater(len(path), 0)
        self.assertEqual(path[0].id, "library")
        self.assertEqual(path[-1].id, "lab")
    
    def test_emergency_routing(self):
        """Test emergency routing to safe zone."""
        from safe_path_app import build_campus_graph, find_safest_route
        
        graph, name_map = build_campus_graph()
        start = name_map["LIBRARY"]
        
        path, cost = find_safest_route(graph, start)
        self.assertIsNotNone(path)
        # Should end at safe zone
        self.assertEqual(path[-1].location_type, "safe_zone")


class TestEdgeCases(unittest.TestCase):
    """Test edge cases and error handling."""
    
    def test_empty_graph_search(self):
        """Test search on empty graph."""
        graph = Graph("Empty")
        bfs = BFS(graph)
        path, _ = bfs.search("a", "b")
        self.assertIsNone(path)
    
    def test_single_node_graph(self):
        """Test search on single-node graph."""
        graph = Graph("Single")
        loc = Location("a", "A", 0, 0)
        graph.add_node(loc)
        
        bfs = BFS(graph)
        path, _ = bfs.search("a", "a")
        # Should handle same-node case gracefully
        self.assertIsNotNone(path) if bfs.search("a", "a")[0] else True


def run_tests():
    """Run all tests with verbose output."""
    print("\n" + "="*80)
    print("SAFE PATH UNIT TEST SUITE - CO1: Testing Algorithm Units")
    print("="*80 + "\n")
    
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add all test classes
    suite.addTests(loader.loadTestsFromTestCase(TestLocationAndEdge))
    suite.addTests(loader.loadTestsFromTestCase(TestGraph))
    suite.addTests(loader.loadTestsFromTestCase(TestSearchAlgorithms))
    suite.addTests(loader.loadTestsFromTestCase(TestHeuristics))
    suite.addTests(loader.loadTestsFromTestCase(TestPEASModel))
    suite.addTests(loader.loadTestsFromTestCase(TestHazardDetection))
    suite.addTests(loader.loadTestsFromTestCase(TestIntegration))
    suite.addTests(loader.loadTestsFromTestCase(TestEdgeCases))
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Summary
    print("\n" + "="*80)
    print(f"Tests run: {result.testsRun}")
    print(f"Successes: {result.testsRun - len(result.failures) - len(result.errors)}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print("="*80 + "\n")
    
    return result.wasSuccessful()


if __name__ == "__main__":
    success = run_tests()
    exit(0 if success else 1)
