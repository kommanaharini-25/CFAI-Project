"""
Core Search Algorithms: BFS, DFS, UCS, A*, Greedy
Applied to Safe Path navigation
"""

from typing import List, Dict, Set, Tuple, Optional, Callable
from models import Location, State, Edge
from knowledge_representation import Graph
import heapq
from collections import deque
from dataclasses import dataclass, field

@dataclass
class SearchMetrics:
    """Track search performance"""
    nodes_expanded: int = 0
    max_frontier_size: int = 0
    path_length: int = 0
    total_cost: float = 0.0
    time_taken: float = 0.0

class SearchAlgorithm:
    """Base class for search algorithms"""
    
    def __init__(self, graph: Graph):
        self.graph = graph
        self.metrics = SearchMetrics()
    
    def reconstruct_path(self, parent: Dict[str, str], start_id: str, 
                        end_id: str) -> List[Location]:
        """Reconstruct path from parent pointers"""
        path = []
        current = end_id
        while current is not None:
            path.append(self.graph.nodes[current])
            current = parent.get(current)
        path.reverse()
        return path
    
    def reset_metrics(self) -> None:
        self.metrics = SearchMetrics()


class BFS(SearchAlgorithm):
    """Breadth-First Search: Complete, optimal for uniform costs"""
    
    def search(self, start_id: str, goal_id: str) -> Tuple[Optional[List[Location]], SearchMetrics]:
        """
        BFS explores level by level
        Good for: unweighted graphs, finding shortest path
        """
        self.reset_metrics()
        
        if start_id not in self.graph.nodes or goal_id not in self.graph.nodes:
            return None, self.metrics
        
        queue = deque([start_id])
        visited = {start_id}
        parent = {start_id: None}
        
        while queue:
            self.metrics.max_frontier_size = max(self.metrics.max_frontier_size, len(queue))
            current_id = queue.popleft()
            self.metrics.nodes_expanded += 1
            
            if current_id == goal_id:
                path = self.reconstruct_path(parent, start_id, goal_id)
                self.metrics.path_length = len(path)
                self.metrics.total_cost = len(path) - 1
                return path, self.metrics
            
            for neighbor_id in self.graph.adjacency_list[current_id]:
                if neighbor_id not in visited:
                    visited.add(neighbor_id)
                    parent[neighbor_id] = current_id
                    queue.append(neighbor_id)
        
        return None, self.metrics


class DFS(SearchAlgorithm):
    """Depth-First Search: Space efficient, not optimal"""
    
    def search(self, start_id: str, goal_id: str, max_depth: int = 50) -> Tuple[Optional[List[Location]], SearchMetrics]:
        """
        DFS explores deeply before backtracking
        Good for: memory-limited environments, maze solving
        """
        self.reset_metrics()
        
        if start_id not in self.graph.nodes or goal_id not in self.graph.nodes:
            return None, self.metrics
        
        stack = [(start_id, 0)]
        visited = set()
        parent = {start_id: None}
        
        while stack:
            self.metrics.max_frontier_size = max(self.metrics.max_frontier_size, len(stack))
            current_id, depth = stack.pop()
            
            if depth > max_depth:
                continue
            
            if current_id in visited:
                continue
            
            visited.add(current_id)
            self.metrics.nodes_expanded += 1
            
            if current_id == goal_id:
                path = self.reconstruct_path(parent, start_id, goal_id)
                self.metrics.path_length = len(path)
                self.metrics.total_cost = len(path) - 1
                return path, self.metrics
            
            for neighbor_id in self.graph.adjacency_list[current_id]:
                if neighbor_id not in visited:
                    parent[neighbor_id] = current_id
                    stack.append((neighbor_id, depth + 1))
        
        return None, self.metrics


class UCS(SearchAlgorithm):
    """Uniform Cost Search: Optimal for any cost function"""
    
    def search(self, start_id: str, goal_id: str) -> Tuple[Optional[List[Location]], SearchMetrics]:
        """
        Expands lowest-cost nodes first
        Good for: weighted graphs, finding optimal cost path
        """
        self.reset_metrics()
        
        if start_id not in self.graph.nodes or goal_id not in self.graph.nodes:
            return None, self.metrics
        
        priority_queue = [(0, start_id)]
        visited = set()
        parent = {start_id: None}
        cost_so_far = {start_id: 0}
        
        while priority_queue:
            current_cost, current_id = heapq.heappop(priority_queue)
            self.metrics.max_frontier_size = max(self.metrics.max_frontier_size, len(priority_queue))
            
            if current_id in visited:
                continue
            
            visited.add(current_id)
            self.metrics.nodes_expanded += 1
            
            if current_id == goal_id:
                path = self.reconstruct_path(parent, start_id, goal_id)
                self.metrics.path_length = len(path)
                self.metrics.total_cost = current_cost
                return path, self.metrics
            
            for edge in self.graph.edges[current_id]:
                neighbor_id = edge.to_loc.id
                new_cost = current_cost + edge.cost()
                
                if neighbor_id not in cost_so_far or new_cost < cost_so_far[neighbor_id]:
                    cost_so_far[neighbor_id] = new_cost
                    parent[neighbor_id] = current_id
                    heapq.heappush(priority_queue, (new_cost, neighbor_id))
        
        return None, self.metrics


class Greedy(SearchAlgorithm):
    """Greedy Best-First Search: Fast but not optimal"""
    
    def __init__(self, graph: Graph, heuristic: Callable[[str, str], float]):
        super().__init__(graph)
        self.heuristic = heuristic
    
    def search(self, start_id: str, goal_id: str) -> Tuple[Optional[List[Location]], SearchMetrics]:
        """
        Expands nodes with lowest heuristic value
        Good for: fast solutions, when optimality not required
        """
        self.reset_metrics()
        
        if start_id not in self.graph.nodes or goal_id not in self.graph.nodes:
            return None, self.metrics
        
        priority_queue = [(self.heuristic(start_id, goal_id), start_id)]
        visited = set()
        parent = {start_id: None}
        
        while priority_queue:
            _, current_id = heapq.heappop(priority_queue)
            self.metrics.max_frontier_size = max(self.metrics.max_frontier_size, len(priority_queue))
            
            if current_id in visited:
                continue
            
            visited.add(current_id)
            self.metrics.nodes_expanded += 1
            
            if current_id == goal_id:
                path = self.reconstruct_path(parent, start_id, goal_id)
                self.metrics.path_length = len(path)
                self.metrics.total_cost = len(path) - 1
                return path, self.metrics
            
            for edge in self.graph.edges[current_id]:
                neighbor_id = edge.to_loc.id
                if neighbor_id not in visited:
                    parent[neighbor_id] = current_id
                    h_value = self.heuristic(neighbor_id, goal_id)
                    heapq.heappush(priority_queue, (h_value, neighbor_id))
        
        return None, self.metrics


class AStar(SearchAlgorithm):
    """A* Search: Optimal and complete with admissible heuristic"""
    
    def __init__(self, graph: Graph, heuristic: Callable[[str, str], float]):
        super().__init__(graph)
        self.heuristic = heuristic
    
    def search(self, start_id: str, goal_id: str) -> Tuple[Optional[List[Location]], SearchMetrics]:
        """
        Combines actual cost g(n) and heuristic h(n): f(n) = g(n) + h(n)
        Good for: optimal solution with guided search
        """
        self.reset_metrics()
        
        if start_id not in self.graph.nodes or goal_id not in self.graph.nodes:
            return None, self.metrics
        
        priority_queue = [(self.heuristic(start_id, goal_id), 0, start_id)]
        visited = set()
        parent = {start_id: None}
        g_score = {start_id: 0}
        
        while priority_queue:
            _, g_curr, current_id = heapq.heappop(priority_queue)
            self.metrics.max_frontier_size = max(self.metrics.max_frontier_size, len(priority_queue))
            
            if current_id in visited:
                continue
            
            visited.add(current_id)
            self.metrics.nodes_expanded += 1
            
            if current_id == goal_id:
                path = self.reconstruct_path(parent, start_id, goal_id)
                self.metrics.path_length = len(path)
                self.metrics.total_cost = g_curr
                return path, self.metrics
            
            for edge in self.graph.edges[current_id]:
                neighbor_id = edge.to_loc.id
                tentative_g = g_curr + edge.cost()
                
                if neighbor_id not in g_score or tentative_g < g_score[neighbor_id]:
                    g_score[neighbor_id] = tentative_g
                    h_value = self.heuristic(neighbor_id, goal_id)
                    f_value = tentative_g + h_value
                    parent[neighbor_id] = current_id
                    heapq.heappush(priority_queue, (f_value, tentative_g, neighbor_id))
        
        return None, self.metrics
