"""
Safe Path Campus Navigation App
This application implements the actual project process:
1. User enters current location in a campus.
2. User enters desired destination inside the same campus.
3. System finds the shortest route using graph search and heuristics.
4. Output shows clear directions and route cost.
"""

from typing import Dict, List, Tuple, Optional
from models import Location, Edge, PEASModel, State, EnvironmentType
from knowledge_representation import Graph
from search_algorithms import AStar
from heuristics import SafePathHeuristics
from safety_module import EmergencyRouter


def add_bidirectional_edge(graph: Graph, from_loc: Location, to_loc: Location,
                           weight: float, accessibility: float = 1.0) -> None:
    """Add a bidirectional connection between two campus locations."""
    graph.add_edge(Edge(from_loc, to_loc, weight=weight, accessibility=accessibility))
    graph.add_edge(Edge(to_loc, from_loc, weight=weight, accessibility=accessibility))


def build_campus_graph() -> Tuple[Graph, Dict[str, str]]:
    """Build a simple campus map for route planning."""
    graph = Graph("Safe Path Campus")

    locations = {
        "LIBRARY": Location("library", "Library", 10, 20, floor=0, location_type="facility"),
        "CAFETERIA": Location("cafeteria", "Cafeteria", 30, 20, floor=0, location_type="facility"),
        "LAB": Location("lab", "Laboratory", 50, 15, floor=0, location_type="facility"),
        "ADMIN_OFFICE": Location("admin_office", "Admin Office", 15, 35, floor=0, location_type="office"),
        "PRINCIPAL_CABIN": Location("principal_cabin", "Principal Cabin", 5, 45, floor=0, location_type="office"),
        "ADMISSION_CABIN": Location("admission_cabin", "Admission Cabin", 35, 5, floor=0, location_type="office"),
        "MAIN_GATE": Location("main_gate", "Main Gate", 0, 0, floor=0, location_type="exit"),
        "BACK_GATE": Location("back_gate", "Back Gate", 60, 40, floor=0, location_type="exit"),
        "AUDITORIUM": Location("auditorium", "Auditorium", 25, 45, floor=0, location_type="facility"),
        "SAFE_ZONE": Location("safe_zone", "Safe Zone", 55, 50, floor=0, location_type="safe_zone"),
    }

    for loc in locations.values():
        graph.add_node(loc)

    add_bidirectional_edge(graph, locations["LIBRARY"], locations["CAFETERIA"], 20)
    add_bidirectional_edge(graph, locations["LIBRARY"], locations["MAIN_GATE"], 25)
    add_bidirectional_edge(graph, locations["CAFETERIA"], locations["AUDITORIUM"], 30)
    add_bidirectional_edge(graph, locations["AUDITORIUM"], locations["BACK_GATE"], 35)
    add_bidirectional_edge(graph, locations["LAB"], locations["BACK_GATE"], 20)
    add_bidirectional_edge(graph, locations["CAFETERIA"], locations["LAB"], 22)
    add_bidirectional_edge(graph, locations["MAIN_GATE"], locations["AUDITORIUM"], 40)
    add_bidirectional_edge(graph, locations["ADMIN_OFFICE"], locations["LIBRARY"], 15)
    add_bidirectional_edge(graph, locations["ADMIN_OFFICE"], locations["AUDITORIUM"], 18)
    add_bidirectional_edge(graph, locations["PRINCIPAL_CABIN"], locations["ADMIN_OFFICE"], 10)
    add_bidirectional_edge(graph, locations["ADMISSION_CABIN"], locations["LIBRARY"], 12)
    add_bidirectional_edge(graph, locations["ADMISSION_CABIN"], locations["CAFETERIA"], 18)
    add_bidirectional_edge(graph, locations["SAFE_ZONE"], locations["BACK_GATE"], 12)

    name_to_id = {name: loc.id for name, loc in locations.items()}
    return graph, name_to_id


def display_project_process() -> None:
    """Print the actual Safe Path project process and intent."""
    print("\n=== Safe Path Project Process ===")
    print("The below steps shows how Safe Path works:")
    print("  1. User enters current campus location.")
    print("  2. User enters target destination.")
    print("  3. System searches the campus map for the shortest path.")
    print("  4. System uses heuristics to guide search efficiently.")
    print("  5. Output shows step-by-step directions and route cost.")


def display_available_locations(name_to_id: Dict[str, str]) -> None:
    """Display campus locations available in the application."""
    print("\nCampus locations available for navigation:")
    for name in sorted(name_to_id.keys()):
        print(f"  - {name}")


def get_location_input(prompt: str, name_to_id: Dict[str, str]) -> Optional[str]:
    """Read a location name from the user and verify it."""
    location_name = input(prompt).strip().upper()
    if location_name not in name_to_id:
        print(f"Location '{location_name}' is not valid. Please enter one of the available names.")
        return None
    return name_to_id[location_name]


def find_shortest_route(graph: Graph, start_id: str, goal_id: str) -> Tuple[Optional[List[Location]], float]:
    """Find the shortest route from start to goal using A* search."""
    heuristic = SafePathHeuristics.euclidean_distance(graph)
    astar = AStar(graph, heuristic)
    path, metrics = astar.search(start_id, goal_id)
    return path, metrics.total_cost if path else float('inf')


def display_route(path: List[Location], total_cost: float) -> None:
    """Show the resulting route in a clear way."""
    if not path:
        print("\nNo route could be found between the selected locations.")
        return

    print("\n=== Safe Path Route ===")
    for step, location in enumerate(path, start=1):
        print(f"  Step {step}: {location.name} ({location.id})")
    print(f"\nEstimated total route cost: {total_cost:.2f}")
    print("The route is computed with heuristic guidance for shorter navigation.")


def find_safest_route(graph: Graph, start_id: str) -> Tuple[Optional[List[Location]], float]:
    """Find the safest evacuation route to the nearest safe zone."""
    safe_zones = [loc_id for loc_id, loc in graph.nodes.items() if loc.location_type == "safe_zone"]
    router = EmergencyRouter(graph, safe_zones)
    path_ids = router.plan_emergency_evacuation(start_id)
    if not path_ids:
        return None, float('inf')

    path = [graph.nodes[node_id] for node_id in path_ids]
    total_cost = sum(
        next((edge.cost() for edge in graph.edges[path[i].id] if edge.to_loc.id == path[i+1].id), 0)
        for i in range(len(path) - 1)
    )
    return path, total_cost


def display_emergency_route(path: List[Location], total_cost: float) -> None:
    """Show the emergency-safe route clearly."""
    if not path:
        print("\nNo emergency-safe route could be found.")
        return

    print("\n=== Emergency Safe Route ===")
    for step, location in enumerate(path, start=1):
        print(f"  Step {step}: {location.name} ({location.id})")
    print(f"\nEstimated safe route cost: {total_cost:.2f}")
    print("This route is chosen to lead the user to the nearest safe zone in an emergency.")


def evaluate_project_route(graph: Graph, start_id: str, goal_id: str, path: List[Location], total_cost: float) -> None:
    """Use the PEAS model to demonstrate route evaluation."""
    peas = PEASModel(environment_type=EnvironmentType.CAMPUS)
    state = State(
        current_location=graph.nodes[start_id],
        goal_location=graph.nodes[goal_id],
        path_taken=path,
        time_elapsed=total_cost,
        safety_score=100.0,
    )
    score = peas.evaluate_performance(state)
    print(f"\nRoute evaluation score: {score:.2f} (higher is better)")


def main() -> None:
    """Run the Safe Path campus navigation application."""
    print("\nWelcome to Safe Path Campus Navigation")
    display_project_process()

    graph, name_to_id = build_campus_graph()
    display_available_locations(name_to_id)

    mode = None
    while mode not in {"1", "2"}:
        print("\nChoose mode:")
        print("  1. Normal route to a specific destination")
        print("  2. Emergency safe route to nearest safe zone")
        mode = input("Enter 1 or 2: ").strip()

    start_id = None
    while start_id is None:
        start_id = get_location_input("\nEnter your current location: ", name_to_id)

    if mode == "1":
        goal_id = None
        while goal_id is None:
            goal_id = get_location_input("Enter your destination: ", name_to_id)

        if start_id == goal_id:
            print("\nYou are already at the destination.")
            return

        path, total_cost = find_shortest_route(graph, start_id, goal_id)
        display_route(path, total_cost)
        if path:
            evaluate_project_route(graph, start_id, goal_id, path, total_cost)
    else:
        path, total_cost = find_safest_route(graph, start_id)
        display_emergency_route(path, total_cost)


if __name__ == "__main__":
    main()
