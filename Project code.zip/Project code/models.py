"""
PEAS Model and State Representation for Safe Path
Performance, Environment, Actuators, Sensors
"""

from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Set
from enum import Enum
import heapq

class EnvironmentType(Enum):
    """Types of environments Safe Path handles"""
    CAMPUS = "campus"
    OFFICE_BUILDING = "office_building"
    RESIDENTIAL = "residential"
    HYBRID = "hybrid"

class HazardType(Enum):
    """Types of hazards/obstacles"""
    BLOCKED_PATH = "blocked_path"
    FIRE = "fire"
    FLOODING = "flooding"
    CONGESTION = "congestion"
    CONSTRUCTION = "construction"

@dataclass
class Location:
    """Represents a location in the environment"""
    id: str
    name: str
    x: float
    y: float
    floor: int = 0
    location_type: str = "waypoint"  # waypoint, exit, safe_zone, facility
    
    def distance_to(self, other: 'Location') -> float:
        """Euclidean distance to another location"""
        return ((self.x - other.x)**2 + (self.y - other.y)**2)**0.5
    
    def __hash__(self):
        return hash(self.id)
    
    def __eq__(self, other):
        return self.id == other.id if isinstance(other, Location) else False

@dataclass
class Edge:
    """Represents a connection between two locations"""
    from_loc: Location
    to_loc: Location
    weight: float = 1.0  # distance or time
    is_blocked: bool = False
    hazards: List[HazardType] = field(default_factory=list)
    accessibility: float = 1.0  # 0 = fully blocked, 1 = fully accessible
    
    def cost(self) -> float:
        """Calculate traversal cost"""
        if self.is_blocked or self.accessibility == 0:
            return float('inf')
        return self.weight / self.accessibility

@dataclass
class State:
    """Represents a state in the search space"""
    current_location: Location
    goal_location: Location
    path_taken: List[Location] = field(default_factory=list)
    hazards_encountered: List[HazardType] = field(default_factory=list)
    time_elapsed: float = 0.0
    energy_used: float = 0.0
    safety_score: float = 100.0  # 0-100
    
    def is_goal(self) -> bool:
        """Check if current state reached goal"""
        return self.current_location == self.goal_location
    
    def __hash__(self):
        return hash(self.current_location.id)
    
    def __eq__(self, other):
        return self.current_location == other.current_location
    
    def __lt__(self, other):
        """For priority queue ordering"""
        return self.time_elapsed < other.time_elapsed

@dataclass
class PEASModel:
    """
    Performance measure: Route optimality (time, distance, safety)
    Environment: Multi-floor campus/building with dynamic hazards
    Actuators: Navigation display, alert system
    Sensors: Location tracking, hazard detection, user input
    """
    performance_metrics: Dict[str, float] = field(default_factory=lambda: {
        "path_optimality": 0.0,
        "safety_rating": 100.0,
        "time_to_destination": 0.0,
        "total_distance": 0.0,
        "user_satisfaction": 0.0
    })
    
    environment_type: EnvironmentType = EnvironmentType.CAMPUS
    is_deterministic: bool = False  # Dynamic hazards make it non-deterministic
    is_fully_observable: bool = False  # Limited sensor range
    is_static: bool = False  # Hazards change over time
    is_discrete: bool = True  # Discrete locations and actions
    
    def evaluate_performance(self, state: State) -> float:
        """Weighted score combining time, distance, and safety"""
        weights = {"time": 0.3, "safety": 0.4, "distance": 0.3}
        time_score = max(0, 100 - state.time_elapsed * 10)
        distance_score = max(0, 100 - state.time_elapsed * 5)
        safety_score = state.safety_score
        
        total = (weights["time"] * time_score + 
                 weights["safety"] * safety_score + 
                 weights["distance"] * distance_score)
        return total
