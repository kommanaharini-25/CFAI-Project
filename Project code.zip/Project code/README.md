Safe Path — Intelligent Campus Navigation

Overview
--------
Safe Path is a focused project that provides assisted navigation inside a campus and emergency-safe routing.
The application demonstrates a simple, usable flow:

1. User enters their current campus location.
2. User chooses normal routing (to a destination) or emergency mode (to nearest safe zone).
3. System computes a route using A* (heuristic-guided shortest path) or an emergency router.
4. The app prints a step-by-step route and an evaluation score from a simple PEAS model.

Files to keep (core project)
----------------------------
- `safe_path_app.py`: User-facing CLI application (run this).
- `models.py`: Data classes and PEAS model for route evaluation.
- `knowledge_representation.py`: Graph representation of the campus.
- `search_algorithms.py`: A* and search helpers used by the app.
- `heuristics.py`: Heuristics for A* (euclidean, etc.).
- `safety_module.py`: Hazard detection and emergency routing utilities.
- `safepath.py`: Placeholder for shared utilities (reserved).

Removed / not needed for basic app
---------------------------------
- `demo.py`, `tests.py`, `csp_solver.py` were removed to keep the workspace focused.
- Compiled cache `__pycache__` removed.

How to run
----------

### Interactive Navigation App
```bash
python safe_path_app.py
```
- Enter one of the displayed location names (e.g., `LIBRARY`, `ADMIN_OFFICE`).
- Choose `1` for a normal route or `2` for an emergency-safe route.

### Algorithm Benchmark (CO2: Search Algorithms & Heuristics)
```bash
python benchmark_algorithms.py
```
- Compares BFS, DFS, UCS, Greedy, and A* on 3 test cases.
- Shows nodes expanded, path cost, runtime, and heuristic admissibility.
- Demonstrates that A* is optimal and expands fewer nodes than UCS.

### Unit Tests (CO1: Testing Algorithm Units)
```bash
python -m pytest test_safe_path.py -v
```
Or:
```bash
python test_safe_path.py
```
- 25 unit tests covering locations, edges, graphs, algorithms, heuristics, PEAS model.
- Tests integration workflows and edge cases.
- All tests pass (25/25).

### Course Outcome Analysis
Open `CO_COVERAGE_ANALYSIS.md` for detailed mapping of your project against all 6 course outcomes (CO1-CO6) with recommendations for enhancements.

Author
------
Prepared as part of the Safe Path project workspace.
